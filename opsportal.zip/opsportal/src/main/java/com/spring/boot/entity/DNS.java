package com.spring.boot.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "dns")
public class DNS {
	
	@Id
	@GeneratedValue
	private int id;
	private String fdqn;  
	private String managementIpAddress;
	
	
	public DNS() {}


	/**
	 * @param id
	 * @param fdqn
	 * @param managementIpAddress
	 */
	public DNS(int id, String fdqn, String managementIpAddress) {
		super();
		this.id = id;
		this.fdqn = fdqn;
		this.managementIpAddress = managementIpAddress;
	}


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the fdqn
	 */
	public String getFdqn() {
		return fdqn;
	}


	/**
	 * @param fdqn the fdqn to set
	 */
	public void setFdqn(String fdqn) {
		this.fdqn = fdqn;
	}


	/**
	 * @return the managementIpAddress
	 */
	public String getManagementIpAddress() {
		return managementIpAddress;
	}


	/**
	 * @param managementIpAddress the managementIpAddress to set
	 */
	public void setManagementIpAddress(String managementIpAddress) {
		this.managementIpAddress = managementIpAddress;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DNS [id=" + id + ", fdqn=" + fdqn + ", managementIpAddress=" + managementIpAddress + "]";
	}
	
}
