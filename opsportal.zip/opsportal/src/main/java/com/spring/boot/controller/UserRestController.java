/**
 * The UserRestController program implements an application that
 * This is the class to handle user related rest end points
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 *//*

package com.spring.boot.controller;

import java.net.URI;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.spring.boot.entity.User;
import com.spring.boot.exception.BadRequestException;
import com.spring.boot.exception.DataNotfoundException;
import com.spring.boot.exception.ErrorDetails;
import com.spring.boot.repo.UserRepo;

@RestController
public class UserRestController {

	@Autowired
	UserRepo userRepo;


	*//**
	 * This method is used to add to some prerequisit user data in db for safari app
	 * Its a GET method input @param empty
	 * 
	 *//*
	@GetMapping(value = "/addSampleUserData")
	public String addSampleUserData() {

		User user1 = new User(999, "sham", "china", 999);
		userRepo.save(user1);
		return "users added successfully";
	}

	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	*//**
	 * This method is used to get user by id for safari app Its a POST method
	 * input @param int as password
	 * 
	 *//*
	@PostMapping(value = "/getUserById")
	public ResponseEntity<?> getUserById(@RequestParam("id") Integer id) {
		
			if(id == null) throw new BadRequestException("id should not be null");
			{
				User user = userRepo.findOne(id);
				if(user == null) {
					throw new DataNotfoundException("user not found!");
				}
			    return new ResponseEntity<>(user, HttpStatus.OK);
			}
		
	  }
	//POST: http://localhost:8082/getUserById?id=999
	
	
	
	// get user by id
		@PostMapping(value = "/getByuserId")
		public  ResponseEntity<?> getUserByIdd(HttpServletRequest request, @RequestParam("userId") Integer userId) {
			
			ErrorDetails errorDetails=new ErrorDetails();
			try
			{
				String url = request.getRequestURI();
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+url);
				
				if(userId!=null) {
					User user = userRepo.findById(userId);
					if(user != null) {
						return new ResponseEntity<>(user, HttpStatus.OK);
					}
					else
					{	
						//ErrorDetails error=new ErrorDetails(new Date(), "userId not found", "userId not found for the userId"+userId, 404);
						errorDetails.setTimestamp(new Date());
						errorDetails.setMessage("userId not found");
						errorDetails.setDetails("userId not found for the userId"+userId);
						errorDetails.setStatuscode(404);

						return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
					}
				}
				else
				{
					errorDetails.setTimestamp(new Date());
					errorDetails.setMessage("userId should not be null");
					errorDetails.setDetails("userId should not be null");
					errorDetails.setStatuscode(400);
					return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
				}
			}catch(Exception e)
			{	
				errorDetails.setTimestamp(new Date());
				errorDetails.setMessage("something went wrong");
				errorDetails.setDetails("something went wrong");
				errorDetails.setStatuscode(500);
				return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
		
      //POST:  http://localhost:8082/getByuserId?userId=99
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@GetMapping(value = "/getAllUser")
	public ResponseEntity<?> getAll() {
	
			List<User> result = (List<User>) userRepo.findAll();
			if (result.size() == 0) {
				//throw new DataNotfoundException("list is empty");
			}
			return new ResponseEntity<>(result, HttpStatus.OK);

	}

}
*/