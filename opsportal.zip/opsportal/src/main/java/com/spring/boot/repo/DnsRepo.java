package com.spring.boot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.boot.entity.DNS;
import com.spring.boot.entity.User;

public interface DnsRepo  extends JpaRepository<DNS, Integer>{

	DNS findByFdqn(String fdqn);

}
