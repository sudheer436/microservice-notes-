package com.spring.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot.entity.DNS;
import com.spring.boot.repo.DnsRepo;

@RestController
public class DNSController {
	
	
		@Autowired
		DnsRepo dnsRepo;
		
		
		/**
		 * This method is used to add to some prerequisit user data in db 
		 * Its a GET method input @param empty
		 * 
		 */
		@GetMapping(value = "/addSampleDNS")
		public String addSampleDNS() {

			DNS dns = new DNS(101, "fdqn_1", "mia_1");
			DNS dns2 = new DNS(102, "fdqn_2", "mia_2");
			dnsRepo.save(dns);
			dnsRepo.save(dns2);
			return "DNS added successfully";
		}

		
		@GetMapping(value = "/getAllDNS")
		public ResponseEntity<?> getAll() {
		
				List<DNS> result = (List<DNS>) dnsRepo.findAll();
				if (result.size() == 0) {
					return new ResponseEntity<>("list is empty", HttpStatus.NOT_FOUND);
				}
				return new ResponseEntity<>(result, HttpStatus.OK);
		}
		
		
		
		
		
		/**
		 * This method is used to get user by id for safari app Its a POST method
		 * input @param int as password
		 * 
		 */
		@PostMapping(value = "/searchDNS")
		public ResponseEntity<?> getDNSByfdqnAndManagementIp(@RequestParam(required = false) String fdqn, 
															 @RequestParam(required = false) String managementIpAddress) {
				if(fdqn != null) 
				{
					DNS dns = dnsRepo.findByFdqn(fdqn);
					if(dns == null) {
						//throw new DataNotfoundException("user not found!");
						return new ResponseEntity<>("DNS not found, please pass valid fdqn", HttpStatus.NOT_FOUND);
					}
				    return new ResponseEntity<>(dns, HttpStatus.OK);
				}
				else
				{
					 return new ResponseEntity<>("fdqn should not be null", HttpStatus.BAD_REQUEST);
				}
		  }
		/**we can pass parameter optionaly in postman as shown below:
		 * 	(becauase we use: @RequestParam(required = false) String fdqn)
		 * 
		 * POST: http://localhost:8082/searchDNS?fdqn=fdqn_1&managementIpAddress=aaa
		 * POST: http://localhost:8082/searchDNS?fdqn=fdqn_1
		 */
		
		
		
		
		
		
		/**
		 * This method is used to get user by id for safari app Its a POST method
		 * input @param int as password
		 * 
		 */
		@PostMapping(value = "/addDNS")
		public ResponseEntity<?> addDNS(@RequestParam(required = false) String fdqn, 
										@RequestParam(required = false) String managementIpAddress)	
		{	
			//public ResponseEntity<?> addDNS(@RequestBody  DNS dns) {
				if(fdqn != null && managementIpAddress!=null)
				{
					DNS dns = new DNS();
					dns.setFdqn(fdqn);
					dns.setManagementIpAddress(managementIpAddress);
					dnsRepo.save(dns);
				    return new ResponseEntity<>(dns, HttpStatus.OK);
				}
				else
				{
					 return new ResponseEntity<>("parameters should not be null", HttpStatus.BAD_REQUEST);
				}
		  }
		
		/** case 1:
		 * //POST: http://localhost:8082/addDNS?fdqn=fdqn_3&managementIpAddress=mia_3
		 */
		
		/**
		 * case 2:
		    {
		        "fdqn": "fdqn_3",
		        "managementIpAddress": "mia_3"
		    }
		 */
		
		
		
		
		
		/**
		 * This method is used to get user by id for safari app Its a POST method
		 * input @param int as password
		 * 
		 */
		@PutMapping(value = "/updateDNS")
		public ResponseEntity<?> updateDNS(@RequestParam(required = false) String fdqn, 
										   @RequestParam(required = false) String managementIpAddress)	
		{		
				if(fdqn != null && managementIpAddress!=null)
				{	
					DNS newDNS= new DNS();
					newDNS = dnsRepo.findByFdqn(fdqn);
					if(newDNS == null) {
						return new ResponseEntity<>("DNS not found, please pass valid fdqn", HttpStatus.NOT_FOUND);
					}
					newDNS.setFdqn(fdqn);
					newDNS.setManagementIpAddress(managementIpAddress);
					dnsRepo.save(newDNS);
				    return new ResponseEntity<>("updated successfully", HttpStatus.OK);
				}
				else
				{
					 return new ResponseEntity<>("parameters should not be null", HttpStatus.BAD_REQUEST);
				}
		  }
		/**
		 * case 1:
		 * PUT: http://localhost:8082/updateDNS?fdqn=fdqn_3&managementIpAddress=mia_3_modified
		 * 
		 * 
		 * PUT: http://localhost:8082/updateDNS?fdqn=fdqn_3 
		   {
		        "fdqn": "fdqn_3_modified",
		        "managementIpAddress": "mia_3_modified"
		    }
		 */
		
		
		
		
		
		/**
		 * This method is used to get user by id for safari app Its a POST method
		 * input @param int as password
		 * 
		 */
		@DeleteMapping(value = "/deleteDNS")
		public ResponseEntity<?> deleteDNS(@RequestParam(required = false) String fdqn, 
										   @RequestParam(required = false) String managementIpAddress)	
		{		
				if(fdqn != null && managementIpAddress!=null)
				{	
					DNS dns = dnsRepo.findByFdqn(fdqn);
					if(dns == null) {
						return new ResponseEntity<>("DNS not found, please pass valid fdqn", HttpStatus.NOT_FOUND);
					}
					dnsRepo.delete(dns);
				    return new ResponseEntity<>("DNS deleted successfully", HttpStatus.OK);
				}
				else
				{
					 return new ResponseEntity<>("parameters should not be null", HttpStatus.BAD_REQUEST);
				}
		  }
		
		/**
		 * DELETE: http://localhost:8082/deleteDNS?fdqn=fdqn_3&managementIpAddress=mia_3_modified
		 */
}
