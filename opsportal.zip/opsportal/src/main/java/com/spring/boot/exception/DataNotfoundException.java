package com.spring.boot.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class DataNotfoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public DataNotfoundException(String message) {
		super(message);
	}
	
	/*private static final long serialVersionUID = 1L;
	
    public DataNotfoundException(String message) {
        super(message);
    }

    public DataNotfoundException(String message, Throwable cause) {
        super(message, cause);
    }*/
}