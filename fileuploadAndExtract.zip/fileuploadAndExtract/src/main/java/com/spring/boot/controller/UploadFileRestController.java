package com.spring.boot.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.io.Files;
import com.spring.boot.entity.Person;
import com.spring.boot.service.FileUploadService;


import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


import org.springframework.web.multipart.MultipartFile;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;  
import org.w3c.dom.NodeList;  
import org.w3c.dom.Node;  
import org.w3c.dom.Element;  

@RestController
public class UploadFileRestController {

	
	@Autowired
	FileUploadService fileUploadService;
	
	/**
	 * How to upload file
	 * 	FYR: https://www.youtube.com/watch?v=xabbFBBn6T8 
	 */
	
	@PostMapping
	public void uploadFile(@RequestParam("file")  MultipartFile file) throws IllegalStateException, IOException {
		
		file.transferTo(new File("D:\\uploadedfile\\"+file.getOriginalFilename()));
		//fileUploadService.uploadFile(file);
	}
	
	
	/**
	 *  How to iterate excel data
	 * 
	 */
	@PostMapping("fetchExcelFile")
	public void fetchExcelFile(@RequestParam("file")  MultipartFile file) {
		
		String filepath = "D:\\"+file.getOriginalFilename();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> "+filepath);
		
		try {
			FileInputStream file1 = new FileInputStream(filepath);
			Workbook workbook = new XSSFWorkbook(file1);
			DataFormatter dataFormatter = new DataFormatter();
			Iterator<Sheet> sheets = workbook.sheetIterator();
			while(sheets.hasNext()) {
				
				Sheet sh = sheets.next();
				System.out.println("Sheet name is "+sh.getSheetName());
				System.out.println("---------");
				Iterator<Row> iterator = sh.iterator();
				while(iterator.hasNext()) {
					Row row = iterator.next();
					Iterator<Cell> cellIterator = row.iterator();
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						String cellValue = dataFormatter.formatCellValue(cell);
						//if(cell.getCellType() == CellType.STRING) {
						//	
						//}
						System.out.print(cellValue+"\t");
					}
					System.out.println();
				}
			}
			workbook.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * How to iterate XML file data
	 * 	FYR: https://www.youtube.com/watch?v=u0I6ob8GQBg
	 */
	
	/*@PostMapping("fetchXMLFile")
	public void fetchXMLFile(@RequestParam("file")  MultipartFile file) throws IllegalStateException, IOException {
		
		ObjectMapper mapper = new XmlMapper();
		
		//String filepath = "D:\\"+file.getOriginalFilename();
		//String filepath = "D:/person.xml";
		//String filepath = "D://person.xml";
		//String filepath = "D://person.xml";
		//String filepath = "D:\\person.xml";
		File file2 = new File("D:\\person.xml");  
		
		//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> "+filepath);
		
		//InputStream inputStream = new FileInputStream(new File("/home/parallels/demo/persons.xml"));
		InputStream inputStream = new FileInputStream(file2);
		TypeReference<List<Person>> typeReference = new TypeReference<List<Person>>() {};
		List<Person> persons = mapper.readValue(inputStream, typeReference);
		for(Person p :persons) {
			System.out.println("name is "+p.getFirstName()+" city is "+p.getAddress().getCity()+" first car is "+p.getCars()[0]+" age is "+p.getAge());
		}
		
	}*/
	
	
	/**
	 * How to iterate XML file data using DOM
	 * 	FYR: https://www.javatpoint.com/how-to-read-xml-file-in-java
	 */
	
	@PostMapping("fetchXMLFileUsingDom")
	public void fetchXMLFileUsingDom(@RequestParam("file")  MultipartFile file2) throws IllegalStateException, IOException {

		try   
		{  
		//creating a constructor of file class and parsing an XML file  
		//File file = new File("D:\\XMLFile.xml");
		File file = new File("D:\\"+file2.getOriginalFilename());  
		//an instance of factory that gives a document builder  
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
		//an instance of builder to parse the specified xml file  
		DocumentBuilder db = dbf.newDocumentBuilder();  
		Document doc = db.parse(file);  
		doc.getDocumentElement().normalize();  
		System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
		NodeList nodeList = doc.getElementsByTagName("student");  
		// nodeList is not iterable, so we are using for loop  
		for (int itr = 0; itr < nodeList.getLength(); itr++)   
		{  
		Node node = nodeList.item(itr);  
		System.out.println("\nNode Name :" + node.getNodeName());  
		if (node.getNodeType() == Node.ELEMENT_NODE)   
		{  
		Element eElement = (Element) node;  
		System.out.println("Student id: "+ eElement.getElementsByTagName("id").item(0).getTextContent());  
		System.out.println("First Name: "+ eElement.getElementsByTagName("firstname").item(0).getTextContent());  
		System.out.println("Last Name: "+ eElement.getElementsByTagName("lastname").item(0).getTextContent());  
		System.out.println("Subject: "+ eElement.getElementsByTagName("subject").item(0).getTextContent());  
		System.out.println("Marks: "+ eElement.getElementsByTagName("marks").item(0).getTextContent());  
		}  
		}  
		}   
		catch (Exception e)   
		{  
		e.printStackTrace();  
		}  
		}  
}
