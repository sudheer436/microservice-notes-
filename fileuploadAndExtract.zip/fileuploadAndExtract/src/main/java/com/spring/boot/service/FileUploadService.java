package com.spring.boot.service;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileUploadService {

	public void uploadFile(MultipartFile file) throws IllegalStateException, IOException {
		// TODO Auto-generated method stub
		
		file.transferTo(new File("D:\\uploadedfile\\"+file.getOriginalFilename()));
		
	}
	
	
}
