/**
 * The UtilitMethods program implements an application that
 * This is the util class for all common and reuse methods
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 *//*

package com.spring.boot.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class UtilitMethods {

	*//**
	 * Use Files class from Java 1.7 to write files, internally uses OutputStream
	 * @param data
	 *//*
	public  void writeUsingFiles(String data, String filePath) {

		try {
			FileWriter fout=new FileWriter(filePath);
			fout.write(data);
			fout.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	*//**
	 * Use Files class from Java 1.7 to write files, internally uses OutputStream
	 * @param data
	 *//*
	public  void writeJsonIntoFiles(List<User> result, String filePath) {
		*//**
		 * writing into file without overwrite
		 * in case need overwrite? just replace below line 
		 * PrintWriter out = new PrintWriter(new FileWriter(filePath));
		 *//*
		try {
			PrintWriter out = new PrintWriter(new FileWriter(filePath, true));
			*//**
			 * converting json to toString
			 *//*
			out.write(((Object) result).toString());
			out.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	*//**
	 * Use Files class from Java 1.7 to write files, internally uses OutputStream
	 * @param data
	 *//*
	public  void writeJsonVehicleValuesIntoFiles(List<Vehicles> result, String filePath) {

		*//**
		 * writing into file without overwrite
		 * in case need overwrite? just replace below line 
		 * PrintWriter out = new PrintWriter(new FileWriter(filePath));
		 *//*
		try {
			PrintWriter out = new PrintWriter(new FileWriter(filePath, true));
			*//**
			 * converting json to toString
			 *//*
			out.write(((Object) result).toString());
			out.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
*/