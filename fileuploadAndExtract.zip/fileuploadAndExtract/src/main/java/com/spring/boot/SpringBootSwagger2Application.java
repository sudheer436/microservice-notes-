/**
* The SpringBootSwagger2Application program implements an application that
* This is the main method for spring boot application
*
* @author  sudheeraprasada
* @version 1.0
* @since   23/09/2021 
*/

package com.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This is the main method for spring boot application.
 * @param args Unused.
 * @return Nothing.
 * 
 */
@SpringBootApplication
public class SpringBootSwagger2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSwagger2Application.class, args);
	
	}
}
