package com.spring.boot.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.boot.entity.NetworkInstanceMapping;
import com.spring.boot.entity.User;

public interface NetworkInstanceMappingRepo  extends JpaRepository<NetworkInstanceMapping, Integer>{

	//NetworkInstanceMapping findOne(String customerCode);

	NetworkInstanceMapping findByCustomerCode(String customerCode);

}
