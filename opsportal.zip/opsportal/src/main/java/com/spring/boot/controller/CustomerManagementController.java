package com.spring.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot.entity.NetworkInstanceMapping;
import com.spring.boot.entity.Person;
import com.spring.boot.entity.User;
import com.spring.boot.exception.BadRequestException;
import com.spring.boot.exception.DataNotfoundException;
import com.spring.boot.repo.NetworkInstanceMappingRepo;
import com.spring.boot.repo.UserRepo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.io.Files;

import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import org.springframework.web.multipart.MultipartFile;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

@RestController
public class CustomerManagementController {

	@Autowired
	NetworkInstanceMappingRepo networkInstanceMappingRepo;

	/**
	 * This method is used to add to some prerequisit user data in db Its a GET
	 * method input @param empty
	 * 
	 */
	@GetMapping(value = "/addSampleUserData")
	public String addSampleUserData() {

		NetworkInstanceMapping networkInstanceMapping = new NetworkInstanceMapping("net101", "appu_1",
				"ROCommunityString_1", "RWCommunityString_1");
		NetworkInstanceMapping networkInstanceMapping2 = new NetworkInstanceMapping("net102", "appu_2",
				"ROCommunityString_2", "RWCommunityString_2");
		networkInstanceMappingRepo.save(networkInstanceMapping);
		networkInstanceMappingRepo.save(networkInstanceMapping2);
		return "users added successfully";
	}

	@GetMapping(value = "/getAllUser")
	public ResponseEntity<?> getAll() {

		List<NetworkInstanceMapping> result = (List<NetworkInstanceMapping>) networkInstanceMappingRepo.findAll();
		if (result.size() == 0) {
			return new ResponseEntity<>("list is empty", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	/**
	 * This method is used to get user by id for safari app Its a POST method
	 * input @param int as password
	 * 
	 */
	@PostMapping(value = "/getUserByCustomerCode")
	public ResponseEntity<?> getUserById(@RequestParam("customerCode") String customerCode) {

		if (customerCode == null)
			throw new BadRequestException("customerCode should not be null");
		{
			NetworkInstanceMapping networkInstanceMapping = networkInstanceMappingRepo.findByCustomerCode(customerCode);
			if (networkInstanceMapping == null) {
				// throw new DataNotfoundException("user not found!");
				return new ResponseEntity<>("user not found, please pass valid customerCode", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<>(networkInstanceMapping, HttpStatus.OK);
		}

	}
	// POST: http://localhost:8082/getUserByCustomerCode?customerCode=net101

	/**
	 * This method is used to get user by id for safari app Its a POST method
	 * input @param int as password
	 * 
	 */
	@PostMapping(value = "/addUser")
	public ResponseEntity<?> addUser(@RequestBody NetworkInstanceMapping nim) {

		if (nim != null) {
			NetworkInstanceMapping networkInstanceMapping = new NetworkInstanceMapping();
			networkInstanceMapping.setCustomerCode(nim.getCustomerCode());
			networkInstanceMapping.setCustomerDescription(nim.getCustomerDescription());
			networkInstanceMapping.setROCommunityString(nim.getROCommunityString());
			networkInstanceMapping.setRWCommunityString(nim.getRWCommunityString());
			networkInstanceMappingRepo.save(networkInstanceMapping);

			return new ResponseEntity<>(networkInstanceMapping, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("customerCode should not be null", HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * { "customerCode": "net103", "customerDescription": "appu_3",
	 * "rwcommunityString": "RWCommunityString_3", "rocommunityString":
	 * "ROCommunityString_3" }
	 */

	@PostMapping
	public void uploadFile(@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException {

		/**
		 * it will take file from input (in postman) and upload/place it in system to
		 * the specified location as shown below
		 */
		file.transferTo(new File("D:\\uploadedfile\\" + file.getOriginalFilename()));
		// fileUploadService.uploadFile(file);

	}

	/**
	 * How to iterate excel data
	 * 
	 */
	@PostMapping("fetchExcelFile") // file format should be .xlsx
	public void fetchExcelFile(@RequestParam("file") MultipartFile file) {

		String filepath = "D:\\" + file.getOriginalFilename();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> " + filepath);

		try {
			FileInputStream file1 = new FileInputStream(filepath);
			Workbook workbook = new XSSFWorkbook(file1);
			DataFormatter dataFormatter = new DataFormatter();
			Iterator<Sheet> sheets = workbook.sheetIterator();
			while (sheets.hasNext()) {

				Sheet sh = sheets.next();
				System.out.println("Sheet name is " + sh.getSheetName());
				System.out.println("---------");
				Iterator<Row> iterator = sh.iterator();
				while (iterator.hasNext()) {
					Row row = iterator.next();
					Iterator<Cell> cellIterator = row.iterator();
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						String cellValue = dataFormatter.formatCellValue(cell);
						// if(cell.getCellType() == CellType.STRING) {
						//
						// }
						System.out.print(cellValue + "\t");
					}
					System.out.println();
				}
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * How to iterate XML file data FYR: https://www.youtube.com/watch?v=u0I6ob8GQBg
	 */
	@PostMapping("fetchXMLFile")
	public void fetchXMLFile(@RequestParam("file")  MultipartFile file) throws IllegalStateException, IOException {
		
		ObjectMapper mapper = new XmlMapper();
		
		String filepath = "D:\\" + file.getOriginalFilename();		
		String filepath2 = "D://person.xml";
		//String filepath = "D://person.xml";
		//String filepath = "D://person.xml";
		//String filepath = "D:\\person.xml";
		//File file2 = new File("D:\\person.xml");  
		
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> "+filepath+" "+"filepath2 "+filepath2);
		//print result: >>>>>>>>>>>>>>>>>>>>>>>> D:\person.xml filepath2 D://person.xml
		
		//InputStream inputStream = new FileInputStream(new File("/home/parallels/demo/persons.xml"));
		FileInputStream inputStream = new FileInputStream(filepath);
		TypeReference<List<Person>> typeReference = new TypeReference<List<Person>>() {};
		List<Person> persons = mapper.readValue(inputStream, typeReference);
		for(Person p :persons) {
			System.out.println("name is "+p.getFirstName()+" city is "+p.getAddress().getCity()
								+" first car is "+p.getCars()[0]+" age is "+p.getAge());
		}
	}
	 

	/**
	 * How to iterate XML file data using DOM FYR:
	 * https://www.javatpoint.com/how-to-read-xml-file-in-java
	 */

	@PostMapping("fetchXMLFileUsingDom")
	public void fetchXMLFileUsingDom(@RequestParam("file") MultipartFile file2)
			throws IllegalStateException, IOException {

		try {
			// creating a constructor of file class and parsing an XML file
			// File file = new File("D:\\XMLFile.xml");
			File file = new File("D:\\" + file2.getOriginalFilename());
			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
			NodeList nodeList = doc.getElementsByTagName("student");
			// nodeList is not iterable, so we are using for loop
			for (int itr = 0; itr < nodeList.getLength(); itr++) {
				Node node = nodeList.item(itr);
				System.out.println("\nNode Name :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					System.out.println("Student id: " + eElement.getElementsByTagName("id").item(0).getTextContent());
					System.out.println(
							"First Name: " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
					System.out.println(
							"Last Name: " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
					System.out.println("Subject: " + eElement.getElementsByTagName("subject").item(0).getTextContent());
					System.out.println("Marks: " + eElement.getElementsByTagName("marks").item(0).getTextContent());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
