/**
* The UserRepo program implements an application that
* This is the dao layer for UserRepo
*
* @author  Sudheeraprasad
* @version 1.0
* @since   23/09/2021 
* 
* 
*/
package com.spring.boot.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.spring.boot.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	User findByPassword(int password);

	User findById(Integer id);

	User findById(long userId);

	
}
